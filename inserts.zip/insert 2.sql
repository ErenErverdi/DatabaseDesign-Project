﻿INSERT INTO UNIVERSITY (UNIVERSITY_NAME)
	VALUES ('Istanbul Technical University');

INSERT INTO INSTITUTE (UNIVERSITY_ID,INSTITUTE_NAME)
	VALUES ('1', 'Institute of Science');

INSERT INTO THESIS_PERSON (PERSON_ID, THESIS_ID, PERSON_ROLE)
	VALUES (3, 2, 'Author'),
			(4, 2, 'Supervisor');

INSERT INTO KEYWORD (KEYWORD_NAME)
	VALUES ('ipek'),
			('sentez'),
			('inceleme'),
			('bombyx');

INSERT INTO THESIS_KEYWORD(KEYWORD_ID, THESIS_ID)
	VALUES (7, 2),
			(8, 2),
			(9, 2),
			(10, 2);

INSERT INTO THESIS_TOPIC (TOPIC_ID, THESIS_ID)
	VALUES (2, 2),
			(3, 2);

INSERT INTO THESIS (TITLE, ABSTRACT, [YEAR], NUM_OF_PAGES, SUB_DATE, [TYPE_ID], INSTITUTE_ID, LANGUAGE_ID)
	VALUES ('İpek fibroin kriyojellerinin sentezi ve mekanik özelliklerinin incelenmesi', 
			'İpek genellikle Bombyx mori adı verilen ipek böcekleri tarafından üretilen bir biyopolimerdir. İpek; fibroin ve serisin olarak isimlendirilen iki proteinden oluşmakta olup ipek liflerinin yapısal proteini olan fibroini bir arada tutan serisin yüksek alkali çözeltilerde çözünür. İpek fibroini, başlıca glisin ve alanin amino asit ünitelerinden oluşan büyük hidrofobik bloklar ile bunların aralarında ve zincir uçlarında daha küçük hidrofilik bloklardan (arjinin ve lizin üniteleri) ibaret çok bloklu bir kopolimer mimarisine sahiptir. Hidrofilik bloklar suda çözünürlüğü sağlarken, hidrofobik bloklar arası asosiyasyonlar, fibroinin rastgele yumak yapısından β-tabaka yapısına bir konformasyon geçişine neden olur. İpek fibroinin yapısındaki β-tabakaları malzemeye dayanıklılık ve sertlik kazandırırken, daha düzensiz olan hidrofilik bloklar tokluğu ve elastisiteyi artırır. İpek fibroinde jelleşmenin fibroin proteininin ikincil yapısındaki konformasyonel geçişlerle meydana geldiği bilinmektedir. Çapraz bağlayıcı ile ipek fibroindeki konformasyonel geçişler kısa sürede gerçekleşerek jel elde edilebileceği son yıllarda grubumuzda yapılan çalışmalar sonucunda ortaya konmuştur. Fibroin molekülleri, birbirlerine 1,4 bütandioldiglisidileter (BDDE) çapraz bağlayıcısıyla bağlandıkça, moleküllerin hareketliliği azalır. Bunun bir sonucu olarak, moleküller arası hidrofobik etkileşimler kuvvetlenerek β-tabaka yapısının çekirdeklenme ve büyüme süreci kolaylaşır. Böylece kısa süre içerisinde jelleşme meydana gelir. Bu çalışmanın amacı mekanik olarak dayanıklı, dışarıdan gelen uyarılara hızlı cevap verebilen kemik hücre mühendisliğinde kullanıma uygun makrogözenekli ipek fibroin iskeletlerinin sentezlenmesidir. Bunun için literatürde ilk defa olarak fibroin moleküllerinin kriyojelleşme yani düşük sıcaklık jelleşme yöntemi uygulanarak -18°C sıcaklıkta donmuş sulu çözeltilerinde çapraz bağlanması sağlanmıştır. Kriyojelleşme tekniğinde; jelleşme reaksiyonları, reaksiyon sisteminin donma noktasının altında ilerlediği için ortamdaki çözücü kristalleri kalıp etkisi yaparak gözenekli bir yapının oluşmasını sağlamış ve böylece makrogözenekli fibroin iskeletleri elde edilebilmiştir. Karşılaştırma amacıyla +50°Cde fibroin hidrojelleri de sentezlenmiştir. Sentezler suda çözünmüş fibroin moleküllerinin 1,4 bütandioldiglisidileter çapraz bağlayıcısı ile N,N,N,N tetrametiletilendiamin (TEMED) katalizörlüğünde -18°C ve +50°Cde gerçekleştirilmiştir. Jelleşme reaksiyonları sırasında fibroin molekülleri üzerindeki fonksiyonel grupların BDDE ile çapraz bağlanma reaksiyonu fotometrik yöntemlerle izlenmiştir. Elde edilen jellerin şişme davranışları, mekanik ve morfolojik özellikleri incelenmiştir.',
			2013, 
			93, 
			'2013-04-23',
			1, 
			2, 
			2);



INSERT INTO INSTITUTE (UNIVERSITY_ID,INSTITUTE_NAME)
	VALUES ('3', 'School of Medicine');

INSERT INTO THESIS_PERSON (PERSON_ID, THESIS_ID, PERSON_ROLE)
	VALUES (10, 5, 'Author'),
			(11, 5, 'Supervisor'),
			(12, 5, 'CoSupervisor');

INSERT INTO KEYWORD (KEYWORD_NAME)
	VALUES ('hemostasis'),
	        ('predictive')

INSERT INTO THESIS_KEYWORD(KEYWORD_ID, THESIS_ID)
	VALUES (18, 5),
			(19, 5);

INSERT INTO THESIS_TOPIC (TOPIC_ID, THESIS_ID)
	VALUES (6, 4);

INSERT INTO THESIS (TITLE, ABSTRACT, [YEAR], NUM_OF_PAGES, SUB_DATE, [TYPE_ID], INSTITUTE_ID, LANGUAGE_ID)
	VALUES ('Measurement of primary hemostasis potential with platelet function analyzer (PFA-100) to investigate the predictive effect on post-operative blood loss in cyanotic and acyanotic pediatric patients', 
            'Ateş, M.S., Measurement of primary hemostasis potential with Platelet Function Analyzer (PFA-IOO) to investigate the predictive effect on post-operative Mood loss in cyanotic and acyanotic pediatric patients, Hacettepe University Faculty of Medicine, Thesis in Thoracic and Cardiovascular Surgery, Ankara 2000. We have investigated hemostatic parameters, including primary hemostasis potential in 20 pediatric patients with or without cyanosis undergoing cardio-pulmonary bypass (CPB) and cardiac surgery to repair congenital defects. The platelet function analyzer (PFA)-IOO is a newly developed instrument that provides a rapid, in vitro, quantitative measurement of platelet adhesion and aggregation in whole blood flowing through a small aperture under high shear conditions. Other parameters monitored included blood loss, prothrombin time (PTZ), INR, activated partial thromboplastin time (APTT), thrombin time (TT), anti-thrombin Ill activity (ATIIIA), fibrinogen and D-dimer levels. Additionally, hematocrit and albumin levels were monitored to assess the level of hemodilution during CPB. Both, cyanotic and acyanotic pediatric patients had evidence of supranormai primary hemostasis potential. Although, measurements in cyanotic patients exhibited a percentage ratio of a little bit high, this was found to be statistically insignificant between cyanotic and acyanotic patients (Collagen-EPI p=0,070 and Collagen-ADP p=O,248). While, in preoperative period, measurements of primary hemotasis potential, coagulation and fibrinolytic system parameters demonstrated no statistically significant difference between cyanotic and acyanotic patients, measurements ofPTZ, INR, TT and D-dimer levels significantly changed in cyanotic patients, after the operation (p<0,05). Longer CPB time in cyanotic patients could be responsible for this difference. A .statistically significant correlation was found between preoperative primary hemotasis potential values and postoperative blood loss, could be indicative of that the PFA-IOO@ system could predict bleeding in postoperative period (p<0,05 r=0,710 Collagen-Epi, r=0,635 Collagen-ADP).',
			2000, 
			87, 
			'2000-02-12', 
			3, 
			5, 
			1);
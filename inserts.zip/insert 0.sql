INSERT INTO dbo.[TYPE] ([TYPE_NAME])
VALUES ('Master'),
		('Doctorate'),
		('Specialization in Medicine'),
		('Proficiency in Art');


INSERT INTO TOPIC (TOPIC_NAME)
	VALUES ('Industrial and Industrial Engineering'),
			('Chemistry'),
			('Polymer Science and Technology'),
			('Fine Arts'),
			('Law'),
			('Thoracic and Cardiovascular Surgery');

INSERT INTO LANGUAGE (LANGUAGE_NAME)
	VALUES ('English'),
			('Turkish'),
			('French'),
			('Italian');

INSERT INTO PERSON (PERSON_NAME, PERSON_SURNAME)
	VALUES ('TUGBA', 'YAMAN'),
			('SELCUK', 'KARABATI'),
			('FATIH', 'AK'),
			('OGUZ', 'OKAY'),
			('MAHMUT', 'OZTURK'),
			('VEYSEL', 'GÜNAY'),
			('BASAK', 'KARAMAN'),
			('PIERANGELO', 'CATALANO'),
			('HAVVA', 'KARAGOZ'),
			('MEHMET SANSER', 'ATES'),
			('RIZA', 'DOGAN'),
			('VOLKAN', 'TUNALI');
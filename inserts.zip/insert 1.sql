﻿INSERT INTO UNIVERSITY (UNIVERSITY_NAME)
	VALUES ('Koc University');

INSERT INTO INSTITUTE (UNIVERSITY_ID,INSTITUTE_NAME)
	VALUES ('1', 'Institute of Science');

INSERT INTO THESIS_PERSON (PERSON_ID, THESIS_ID, PERSON_ROLE)
	VALUES (1, 1, 'Author'),
			(2, 1, 'Supervisor');

INSERT INTO KEYWORD (KEYWORD_NAME)
	VALUES ('clustering'),
			('optimization'),
			('rfid'),
			('retail'),
			('shopping'),
			('grocery');

INSERT INTO THESIS_KEYWORD(KEYWORD_ID, THESIS_ID)
	VALUES (1, 1),
			(2, 1),
			(3, 1),
			(4, 1),
			(5, 1),
			(6, 1);

INSERT INTO THESIS_TOPIC (TOPIC_ID, THESIS_ID)
	VALUES (1, 1);

INSERT INTO THESIS (TITLE, ABSTRACT, [YEAR], NUM_OF_PAGES, SUB_DATE, [TYPE_ID], INSTITUTE_ID, LANGUAGE_ID)
	VALUES ('Clustering grocery customers'' in-store shopping paths by using optimization-based models', 
			'This thesis investigates the potential benefits of Radio Frequency Identification (RFID) Technology at shopping cart tagging level in grocery retailing. For this purpose, a grocery shopping cart is equipped with a wireless video camera. The customers of the store, in which the experiments are conducted, use this cart during their shopping travels. The location of the shopping cart is reasonably close to the location of the customer, therefore the recorded path information, via the camera attached to the shopping cart, is considered as the shopping path information of the customer. Along with this shopping path information, shopping lists and receipts of customers are collected. The collected data is analyzed by using a data mining tool, clustering. Clustering is segmentation of data objects into different groups, such that the objects in the same group are more similar, in some sense, than the objects in the other groups. We develop a number of optimization-based mathematical models in order to use for clustering our data, instead of using the existing ones. The models that consider the shopping path information are classified into two groups: ?shopping-path based clustering? and ?time-based clustering.? The first group of models considers in which sequence the store coordinates are visited by each customer. The second group of models ignores this information and only considers the time spent at each store coordinate by each customer. The remaining two models are solved for the shopping list and shopping receipt data. We explore that the different type of models provide different insights into the in-store shopping behaviors. In addition, we develop some hypotheses about shopping trends depending on the evaluation of the cluster results. These hypotheses are tested by using statistical methods and are validated by providing cluster examples. Moreover, analysis of all generated clusters enables us to discover hidden characteristics, which can be converted into knowledge in order to manage customer relations successfully, in our data set.', 
			2008, 
			169, 
			'2008-01-07', 
			1, 
			1, 
			1);
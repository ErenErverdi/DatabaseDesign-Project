INSERT INTO UNIVERSITY (UNIVERSITY_NAME)
	VALUES ('Hacettepe University');

INSERT INTO INSTITUTE (UNIVERSITY_ID,INSTITUTE_NAME)
	VALUES ('1', 'Institute of Social Sciences');

INSERT INTO THESIS_PERSON (PERSON_ID, THESIS_ID, PERSON_ROLE)
	VALUES (5, 3, 'Author'),
			(6, 3, 'Supervisor');

INSERT INTO KEYWORD (KEYWORD_NAME)
	VALUES ('idealise'),
	        ('culture'),
		    ('figuratif'),
		    ('lyrique');

INSERT INTO THESIS_KEYWORD(KEYWORD_ID, THESIS_ID)
	VALUES (10, 3),
			(11, 3),
			(12, 3),
			(13, 3);

INSERT INTO THESIS_TOPIC (TOPIC_ID, THESIS_ID)
	VALUES (4, 3);

INSERT INTO THESIS (TITLE, ABSTRACT, [YEAR], NUM_OF_PAGES, SUB_DATE, [TYPE_ID], INSTITUTE_ID, LANGUAGE_ID)
	VALUES ('Mouvement figuratif lyrique', 
            'Lhomme de forme beau-ideal, idealise de culture antique et son mouvement lyrique â ses poses simultanees, se presentent dans les posesdes mannequins et modeles du monde de publicite actuel. Cette comprehension, a ete la source pour creer une langue figurative et propre, que complete le passe avec aujourdhui et lavenir. Dans les societes de consummation de notre siecle lhomme, sourtout la femme, est reduit a un objet de consommation, et a lamper (humer). A cette composition au point de vue de developper une comprehension au point du vue de leffet et critique le deşsin de la femme commençait â dominer. On a cherche une profondeur de sens â lexplication plastique de motif de femme par les sur deformation s et surmetamorphoses nees des caracteristiques lyriques et abstraits des formes, couleurs, peintes. Dans les compositions, la comprehension de "construire toute suite" a domine aux elements de lyrique, active plastique construction. Dans le delai de construire vite des compositions, on a donne beaucoup dimportances aux relations rytmique-organiques entre celui qui exerce et celui qui est exerce. Pendant la formation lyrique spontane- calligraphique de motif et des motifs; les activites nees des differences des valeurs vif et fonce et les activites de direction des mouvements de bras et pinceau, couleur et lignes colorees et plans et formes, precisent le "mouvement". On a accorde de limportance par la notion de sujet-sens pour arriver â la totalite de composition pendant letude des relations lieu-figure et pendant la duree danalyse de motif de figure par des elements de construction plastique active.',
			1995, 
			80, 
			'1995-12-03', 
			4, 
			3, 
			3);
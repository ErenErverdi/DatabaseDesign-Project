INSERT INTO UNIVERSITY (UNIVERSITY_NAME)
	VALUES ('Sapienza University of Rome');

INSERT INTO INSTITUTE (UNIVERSITY_ID,INSTITUTE_NAME)
	VALUES ('1', 'International Institute');

INSERT INTO THESIS_PERSON (PERSON_ID, THESIS_ID, PERSON_ROLE)
	VALUES (7, 4, 'Author'),
			(8, 4, 'Supervisor'),
			(9, 4, 'Supervisor');

INSERT INTO KEYWORD (KEYWORD_NAME)
	VALUES ('giuridico'),
	        ('concepito'),
		    ('Romano'),
		    ('Turco');

INSERT INTO THESIS_KEYWORD(KEYWORD_ID, THESIS_ID)
	VALUES (14, 4),
			(15, 4),
			(16, 4),
			(17, 4);

INSERT INTO THESIS_TOPIC (TOPIC_ID, THESIS_ID)
	VALUES (5, 4);

INSERT INTO THESIS (TITLE, ABSTRACT, [YEAR], NUM_OF_PAGES, SUB_DATE, [TYPE_ID], INSTITUTE_ID, LANGUAGE_ID)
	VALUES ('Lo stato giuridico del bambino concepito nel diritto Romano e nel diritto Turco', 
            'Today, in the countries belonging to the Roman-Germanic legal system, it is possible to distinguish two currents of legal thought regarding the legal status of the unborn child: one is the legal thought current in which the Iustinian influence is strongly felt; the other is the legal thought current of Pandektist origin. The identification of these two currents of legal thought is achieved through a two-step comparative analysis, which, although closely related, must be strictly separated: Words and concepts, principles and norms (These two steps correspond to the last two books of Iustinians Digesta: De verborum significatione and De diversis regulis iuris antiqui). This analysis allows to reconcile and distinguish between concepts and principles (abstract and positivist concepts as opposed to concrete or natural concepts, and the principle of exceptional equality as opposed to the principle of ontological equality between fetus and child). Despite the use of abstract concepts, Turkish-Swiss law remains faithful to the Iustinian tradition with regard to the nondum Nats. The clearest indication of this is the provision in Article 28 of the Turkish Civil Code and the corresponding Article 31 of the Swiss Civil Code. Pursuant to the relevant articles, the child (fr. enfant, alm. Kind, it. infante) acquires the capacity to exercise rights (fr. jouissance des droits civils, alm. Rechtsfähigkeit, it. godimento dei diritti civili) from the moment of conception (fetus, fr. enfant conçu, alm. Kind vor der Geburt, it. infante concepito), provided that the child is born alive. As a matter of fact, every human being has the capacity to acquire rights (Art. 8/I TCC; cf.: Art. 11/I IMK). Nevertheless, the risk that the concrete existence in the womb is turned into an assumption under the influence of Pandectist doctrines cannot be ruled out. Today, the most important task of novelists is to refresh the historical memory of jurists by going back to the original sources (zurück zu Justinian!).',
			2011, 
			123, 
			'2011-08-21', 
			2, 
			4, 
			4);